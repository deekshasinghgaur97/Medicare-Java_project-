export class Credentials {
    username!: string;
    password!: string;
}